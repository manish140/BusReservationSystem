import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ScheduleService } from '../service/schedule.service';
import { faSearch, faTrash, faPenSquare,faEye } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-searchschedule',
  templateUrl: './searchschedule.component.html',
  styleUrls: ['./searchschedule.component.css']
})
export class SearchscheduleComponent implements OnInit {
  faSearch = faSearch;
  faTrash = faTrash;
  faPenSquare = faPenSquare;
  scheduleData: any = [];
  data: any = {};
  @Output() updateSchedule: EventEmitter<any> = new EventEmitter();

  constructor(private scheduleService: ScheduleService) { }




  ngOnInit(): void {
  
  this.getAllSchedules();
}
getAllSchedules() {
  this.scheduleService.getAllSchedules().subscribe((res: any) => {
    this.scheduleData = res;
  })
}

searchSchedule() {
  this.scheduleService.searchSchedule(this.data.schedule_Id).subscribe((res: any) => {
    let schedule_Id: any = [];
    schedule_Id[0] = res;
    this.scheduleData = schedule_Id;
    alert("Bus Schedule is available");
  },
  (error) => { 
    alert("Bus Schedule is not available");
  })
}

delete(scheduleID) {
  this.scheduleService.deleteSchedule(scheduleID).subscribe((res: any) => {
    alert('Schedule delete successfully');
    this.getAllSchedules();
  })
}

update(schedule)
{
  console.log('emitting from search schedule');
  this.updateSchedule.emit(schedule);
}
}
