import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common'
import { AppComponent } from './app.component';
import { AddBookingComponent } from './add-booking/add-booking.component';
import { AppRoutingModule } from './/app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PassengerComponent } from './passenger/passenger.component';
import { BookingDetailsComponent } from './booking-details/booking-details.component';
import { ViewBookingsComponent } from './view-bookings/view-bookings.component';
import { BookingHomeComponent } from './booking-home/booking-home.component'; 
import {DataTablesModule} from 'angular-datatables';
import { LoginComponent } from './login/login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { AddscheduleComponent } from './addschedule/addschedule.component';
import { ScheduleadminComponent } from './scheduleadmin/scheduleadmin.component';
import { SearchscheduleComponent } from './searchschedule/searchschedule.component';
import { UpdatescheduleComponent } from './updateschedule/updateschedule.component';
import { AddbusComponent } from './addbus/addbus.component';
import { DeletebusComponent } from './deletebus/deletebus.component';
import { UpdatebusComponent } from './updatebus/updatebus.component';
import { ViewallbusesComponent } from './viewallbuses/viewallbuses.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { DataComponent } from './data/data.component';

@NgModule({
  declarations: [
    AppComponent,
    AddBookingComponent,
    PassengerComponent,
    BookingDetailsComponent,
    ViewBookingsComponent,
    BookingHomeComponent,
    LoginComponent,
    AdminHomeComponent,
    UserHomeComponent,
    AddscheduleComponent,
    ScheduleadminComponent,
    SearchscheduleComponent,
    UpdatescheduleComponent,
    AddbusComponent,
    DeletebusComponent,
    UpdatebusComponent,
    ViewallbusesComponent,
    RegisterComponent,
    HomeComponent,
    AdminLoginComponent,
    HeaderComponent,
    FooterComponent,
    DataComponent,
    
  ],
  imports: [
    BrowserModule,

    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    DataTablesModule,


  ],
  providers: [
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
