import { Component, OnInit } from '@angular/core';
import { ScheduleService } from '../service/schedule.service';

@Component({
  selector: 'app-addschedule',
  templateUrl: './addschedule.component.html',
  styleUrls: ['./addschedule.component.css']
})
export class AddscheduleComponent implements OnInit {
  data: any = {};
  payload: any = [];
  bus: any = {};
  source: any = {};
  destination: any = {};

  constructor(private scheduleService: ScheduleService) { }

  ngOnInit(): void {
  }

  addSchedule() {
    console.log(this.data.departure, '-', this.data.arrival)
    this.scheduleService.searchBus(this.data.bus).subscribe((res: any) => {
      this.bus = res;
      this.scheduleService.getBusstop(this.data.source).subscribe((res: any) => {
        this.source = res;
        this.scheduleService.getBusstop(this.data.destination).subscribe((res: any) => {
          this.destination = res;
          this.payload = JSON.parse(JSON.stringify(this.data));
          this.payload.bus = this.bus;
          this.payload.source = this.source;
          this.payload.destination = this.destination;
          this.payload.departure = this.data.departure;
          this.payload;
          this.payload.arrival = this.data.arrival;
  
          this.scheduleService.addSchedule(this.payload).subscribe((res: any) => {
            
            alert("Schedule added successfully");
          },
            (error) => {
              alert("added successfully");
            })
        })
      })
    })
  
  }

}
