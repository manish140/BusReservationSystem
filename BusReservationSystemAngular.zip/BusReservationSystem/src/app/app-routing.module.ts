import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AddbusComponent } from './addbus/addbus.component';
import { ViewallbusesComponent } from './viewallbuses/viewallbuses.component';
import { AddscheduleComponent } from './addschedule/addschedule.component';
import { SearchscheduleComponent } from './searchschedule/searchschedule.component';
import { UpdatescheduleComponent } from './updateschedule/updateschedule.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { AddBookingComponent } from './add-booking/add-booking.component';
import { ViewBookingsComponent } from './view-bookings/view-bookings.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'home',component:HomeComponent,
children:[
  {path:'admin-login',component:AdminLoginComponent},
  {path:'login',component:LoginComponent},
]},
{path:'home/admin-login/admin-home',component:AdminHomeComponent,
children:[
  {path:'addbus',component:AddbusComponent},
  {path:'viewallbuses',component:ViewallbusesComponent},
  {path:'addschedule',component:AddscheduleComponent},
  {path:'searchschedule',component:SearchscheduleComponent},
  {path:'updateschedule',component:UpdatescheduleComponent}, 
]},
{path:'home/login/user-home',component:UserHomeComponent,
children:[
  { path:'add-booking',component:AddBookingComponent},
  {path:'view-bookings',component:ViewBookingsComponent},
]},
{path:'add-booking',component:AddBookingComponent},
{path:'view-bookings',component:ViewBookingsComponent},
{path:'home/login/register',component:RegisterComponent},
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
