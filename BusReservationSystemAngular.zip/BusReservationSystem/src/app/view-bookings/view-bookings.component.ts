import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Booking, BookingServiceService } from '../service/booking-service.service';
import { Observable,Subject } from "rxjs"; 
import { DataTableDirective } from 'angular-datatables';
import { FormGroup, FormControl ,Validators} from '@angular/forms'; 

@Component({
  selector: 'app-view-bookings',
  templateUrl: './view-bookings.component.html',
  styleUrls: ['./view-bookings.component.css']
})
export class ViewBookingsComponent implements OnInit {

  bookingData: any = [];
  data: any = {};
  constructor(private bookingService: BookingServiceService, private router: Router) { }
        
  ngOnInit(): void {
    
  }
  searchBooking() {
    this.bookingService.getBookingDetails(this.data.bookingId).subscribe((res: any) => {
      let book: any = [];
    book[0] = res;
      this.bookingData = book;
      alert("Booking is available");
    },
    (error) => { 
      alert("Booking is not available");
    })
  }
  delete(bookingID) {
    this.bookingService.deleteBooking(bookingID).subscribe((res: any) => {
      alert('Schedule delete successfully');
      
    })
  }
  
 

 
}