import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { DatePipe } from '@angular/common'
import { Booking,BusStop, BookingServiceService,BusSchedule} from '../service/booking-service.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-booking',
  templateUrl: './add-booking.component.html',
  styleUrls: ['./add-booking.component.css']
})
export class AddBookingComponent implements OnInit {
  input: any = {}
  availableBuses: BusSchedule[];
  status:boolean=false
  constructor(private bookingService: BookingServiceService, private router: Router, public datepipe: DatePipe) { }

  ngOnInit():void {
   
  }


  search(): any {
    console.log(this.input);
    if(this.input.source==this.input.destination)
    {alert("From Location and To Location cannot be same");}
    else{
    this.bookingService.checkBuses(this.input).subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
}
handleSuccessfulResponse(response) {
  console.log(response);
  this.availableBuses = response;
  this.status=true;
  
}
selectBus(scheduleId) {
  console.log(scheduleId);
  this.router.navigate(['/passenger'], { queryParams: {scheduleId: scheduleId}});
}

logout()
{
  this.router.navigate(['/login']);
}
}