import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Time } from '@angular/common';

@Injectable({
  providedIn: 'root'
})


 export class BusInfo{
     busId:number
     busType:string
     busOperator:string
     seatCapacity:number
     constructor(busId:number,busType:string,busOperator:string, seatCapacity:number){
         this.busId = busId;
         this.busType = busType;
         this.busOperator=busOperator;
         this.seatCapacity = seatCapacity;
     }   
 }
 

 
 @Injectable({
   providedIn: 'root'
 })
 export class AdminService {
   
   constructor(private http:HttpClient) { }
   
   public updateBus(busId:number){
     return this.http.put("http://localhost:8081/buses/"+busId,{responseType:'text' as 'json'});
   }
   public addBus(bus:any){
     return this.http.post("http://localhost:8081/buses/addBus",bus);
   }
   public deleteBus(busid:number){
     return this.http.delete("http://localhost:8081/buses/deleteBus/"+busid,{responseType:'json'});
   }
   public getBus(bus_Id:number){
     return this.http.get("http://localhost:8081/buses/getBus/"+bus_Id,{responseType:'json'});
   }
    getAllBuses():Observable<any>{
     return this.http.get("http://localhost:8081/buses/allBuses");
   }
 
 }
