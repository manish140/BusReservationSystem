import { Injectable } from '@angular/core';
import { logging } from 'protractor';
import { HttpClient,HttpClientModule,HttpHeaders} from '@angular/common/http';
import { retry,catchError} from 'rxjs/operators';  
import { Observable,pipe,throwError} from 'rxjs'
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};

export class Booking{
  bookingId:String;
  user:User;
  busSchedule:BusSchedule;
  passenger:Passenger[];
  bookingDate:Date;
  noOfPassengers:number;
}
export class BusStop{
  busStopCode:String;
  busStopName:String;
  busStopLocation:String;
}
export class BusSchedule{
  scheduleId:string; 
	bus: Bus 
	source:BusStop;
	destination:BusStop; 
	fare:number;
	availableSeats:number;
	departureTime:Date;
	arrivalTime:Date;
}
export class Bus {
 
	busId:number;
	busOperator:String; 
	busType:String;
	seatCapacity:number; 
  
}
export class User{
  
	userId:number;
	username:string; 
	password:string; 
	name:string;
	email:string; 
	phone:number;
}

export class Passenger{
  passengerId:number;
	name:string;
	age:number;
	gender:string;
	phone:number;
}
@Injectable({
  providedIn: 'root'
})
export class BookingServiceService {
  userdetails:User;
  private baseUrl = 'http://localhost:8081/bookings';
  constructor(private http:HttpClient) { }

 
  bookTickets(booking: Booking) {
    return this.http.post('http://localhost:8081/bookings/addBooking/',booking);
   
    }
  getBookingList():Observable<any>{
    return this.http.get(`${this.baseUrl}`+'/allBookings');  
  }
  deleteBooking(bookingId: number): Observable<{}> {  
    const url = `${this.baseUrl}/${bookingId}`;
    return this.http.delete(url,httpOptions).pipe(
      catchError(this.handleError)
    );
  }
  getBookingDetails(bookingId){
   return this.http.get('http://localhost:8081/bookings/'+bookingId);
  }
  getAllSchedules(){
    return this.http.get('http://localhost:8081/schedules/allSchedules');
  }
  searchSchedule(scheduleId){
    return this.http.get('http://localhost:8081/schedules/'+ scheduleId)
  }
  checkBuses(input: any) {
    console.log(input);
    return this.http.get('http://localhost:8081/bookings/SearchBuses/'+input.source+'/'+input.destination+'/'+input.date);
  }
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }
}
