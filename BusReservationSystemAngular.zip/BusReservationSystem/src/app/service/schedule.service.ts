import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {

  constructor(private http: HttpClient) { }
  addSchedule(body) {
    return this.http.post('http://localhost:8081/addSchedule',body)
  }
  getAllSchedules(){
    return this.http.get('http://localhost:8081/allSchedules');
  }
  searchSchedule(scheduleId){
    return this.http.get('http://localhost:8081/'+ scheduleId)
  }

  deleteSchedule(scheduleId) {
    return this.http.delete('http://localhost:8081/schedule/' + scheduleId);
  }

  searchBus(busId) {
    return this.http.get('http://localhost:8081/buses/' + busId);
  }

  getBusstop(busStopCode){
    return this.http.get('http://localhost:8081/busStops/' + busStopCode);
  }

}

