import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking,BusStop, BookingServiceService } from '../service/booking-service.service';

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.css']
})
export class BookingDetailsComponent implements OnInit {
  bookingId:String;
  bookingDetails:Booking;
  constructor(private route: ActivatedRoute, private bookingService: BookingServiceService, private router: Router) { }

  ngOnInit(): void {
    this.route.queryParams
    .subscribe(params => {
      this.bookingId = params.bookingID;
      this.getBooking();
    });
  }
  getBooking() {
    console.log('booking id received is ', this.bookingId);
    this.bookingService.getBookingDetails(this.bookingId).subscribe((data: any) => {
      this.bookingDetails = data;
      console.log('booking details ', data);
    })
  }
}
