import { Component, OnInit } from '@angular/core';
import { Booking,BusStop,User,BusSchedule,Passenger, BookingServiceService } from '../service/booking-service.service';
import {ActivatedRoute,Router} from "@angular/router";

@Component({
  selector: 'app-passenger',
  templateUrl: './passenger.component.html',
  styleUrls: ['./passenger.component.css']
})
export class PassengerComponent implements OnInit {
  State: any = ['M','F'];
  scheduleId:string;
  passengersData:Passenger[]=[];
  pdata:Passenger=new Passenger();
  busSchedule:BusSchedule;
  booking:Booking;
  user:User;
  printdate:any;
  j=1;

  constructor(private route: ActivatedRoute, private bookingService: BookingServiceService, private router: Router) { }

  ngOnInit():void {
    this.route.queryParams
    .subscribe(params => {
      this.scheduleId = params.scheduleId;
    });
    console.log(this.scheduleId);
  }

  add() {
    console.log(this.pdata);
    this.passengersData.push(this.pdata);
    this.pdata=new Passenger();
   this.j++;
  }

  confirm() {
    console.log('passenger data ', this.passengersData);
    console.log("Task completed");
    let date = new Date();
      this.printdate = date;
    this.bookingService.searchSchedule(this.scheduleId).subscribe((res: any) => {
       this.busSchedule = res;
       //this.user = this.myservice.userdetails;
          this.booking = {
            bookingId:"b123",
         user:this.bookingService.userdetails,
         busSchedule: this.busSchedule,
         passenger:this.passengersData,
          bookingDate: this.printdate,
         noOfPassengers:this.passengersData.length,
       };
       console.log(this.booking);
       this.bookingService.bookTickets(this.booking).subscribe((response: any) => {

         alert ('Bus Booking successful:'+response.bookingId);
        // console.log('booking id sending is ', response.bookingId)
         this.router.navigate(['/bookingdetails'], { queryParams: {bookingID: response.bookingId}});
       })
     })
  }

}