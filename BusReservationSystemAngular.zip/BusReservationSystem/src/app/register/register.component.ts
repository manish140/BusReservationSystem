import { Component, OnInit } from '@angular/core';
import {IUserService} from "../service/user.service";
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

 //userRegistrationForm : FormGroup;
 constructor(private userService:IUserService,private fb:FormBuilder) { }

 ngOnInit() {
   // this.userRegistrationForm = this.fb.group({
   //   userId:[''],
   //   userName:[''],
   //   phoneNumber:[''],
   //   email:[''],
   //   password:[''],
   //   confirmPassword:['']

   // });
 }

 registerUser(){
   //console.log(this.userRegistrationForm.value);
   // this.userService.postUserData(this.userRegistrationForm.value).subscribe((response)=>{

   // })
 }

}
