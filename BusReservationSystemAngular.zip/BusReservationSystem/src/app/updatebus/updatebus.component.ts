import { Component, OnInit } from '@angular/core';
import { BusInfo, AdminService } from '../service/admin.service';

@Component({
  selector: 'app-updatebus',
  templateUrl: './updatebus.component.html',
  styleUrls: ['./updatebus.component.css']
})
export class UpdatebusComponent implements OnInit {

  constructor(private addservice:AdminService) { }
  busInfo: BusInfo = new BusInfo(0,"","",0);
  busDetails:any;
  busId: any;
  errormessage: any;
  message: any;
  error:any

  ngOnInit(): void {
  }

  
  updateBus(){
    // if(window.confirm('Order Updated Sucessfully OrderId:' +this.orderId))
     this.addservice.updateBus(this.busId).subscribe((data) => {this.message=data});
  
     }}


