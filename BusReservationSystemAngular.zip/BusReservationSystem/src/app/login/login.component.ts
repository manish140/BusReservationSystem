import { Component, OnInit } from '@angular/core';
import {IUserService} from "../service/user.service";
import{User,BookingServiceService} from "../service/booking-service.service";
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  info:any={}
  constructor(private userservice:IUserService,private router:Router) { }

  ngOnInit(){
  }

  validate(){
   // console.log(this.info);
    this.userservice.checkLogin(this.info).subscribe((response: any) => {
      console.log('The user details', response);

      if (response != null) {
        alert("Login succesful")
        this.router.navigate(['dashboard']);
      }
      else{
      alert("Invalid credentials");
      }
    });
  }
  // getUserInfo(){
  //   this.userService.getUserData().subscribe((data)=>{

  //     console.log(data);

}