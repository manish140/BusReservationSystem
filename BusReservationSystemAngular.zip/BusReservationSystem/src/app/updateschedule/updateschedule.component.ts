import { Component, OnInit } from '@angular/core';
import { ScheduleService } from '../service/schedule.service';

@Component({
  selector: 'app-updateschedule',
  templateUrl: './updateschedule.component.html',
  styleUrls: ['./updateschedule.component.css']
})
export class UpdatescheduleComponent implements OnInit {
  showDiv = false;
  data: any = {};
  payload: any = [];
  bus: any = {};
  source: any = {};
  destination: any = {};

  constructor(private scheduleService: ScheduleService) { }


  ngOnInit(): void {
  }
  update() {
    this.scheduleService.searchBus(this.data.bus).subscribe((res: any) => {
      this.bus = res;
      this.scheduleService.getBusstop(this.data.source).subscribe((res: any) => {
        this.source = res;
        this.scheduleService.getBusstop(this.data.destination).subscribe((res: any) => {
          this.destination = res;
          this.payload = JSON.parse(JSON.stringify(this.data));
          this.payload.bus = this.bus;
          this.payload.source = this.source;
          this.payload.destination = this.destination;
          this.payload.departure = this.data.departure;
          this.payload; this.payload.arrival = this.data.arrival;

          this.scheduleService.addSchedule(this.payload).subscribe((res: any) => {
            alert("Schedule updated successfully");
            this.showDiv = false;
          },
            (error) => {
              alert("successfully updated");
            })
        })
      })
      
    })
  }

  updateSchedule(schedule) {
    console.log('received here')
    this.data.scheduleId = schedule.scheduleId;
    this.data.bus = schedule.bus.busNumber;
    this.data.source = schedule.source.airportCode;
    this.data.destination = schedule.destination.airportCode;
    this.data.fare = schedule.fare;
    this.data.departure = schedule.departure;
    this.data.arrival = schedule.arrival;
    this.showDiv = true;
  }

}
