import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallbusesComponent } from './viewallbuses.component';

describe('ViewallbusesComponent', () => {
  let component: ViewallbusesComponent;
  let fixture: ComponentFixture<ViewallbusesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewallbusesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallbusesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
