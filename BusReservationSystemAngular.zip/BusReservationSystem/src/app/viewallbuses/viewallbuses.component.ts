import { Component, OnInit } from '@angular/core';
import { BusInfo, AdminService } from '../service/admin.service';
import { Observable,Subject } from "rxjs"; 

@Component({
  selector: 'app-viewallbuses',
  templateUrl: './viewallbuses.component.html',
  styleUrls: ['./viewallbuses.component.css']
})
export class ViewallbusesComponent implements OnInit {

  busInfo: BusInfo = new BusInfo(0,"","",0);
  allBuses:any;
  constructor(private adminService:AdminService) { }

  ngOnInit(): void {
    this.adminService.getAllBuses().subscribe(data =>{  
      this.allBuses =data;   
      })  
  }
 getAllBuses(){
  this.adminService.getAllBuses().subscribe((data)=>this.allBuses = data);
 }
}
