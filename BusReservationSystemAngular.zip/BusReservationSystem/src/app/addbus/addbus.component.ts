import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BusInfo, AdminService } from '../service/admin.service';

@Component({
  selector: 'app-addbus',
  templateUrl: './addbus.component.html',
  styleUrls: ['./addbus.component.css']
})
export class AddbusComponent implements OnInit {

  busInfo: BusInfo = new BusInfo(0,"","",0);
  message: any;
  errormessage: any;
    
    
  constructor(private addservice:AdminService,private router:Router) { }

  ngOnInit(): void {
  }
  addBus(){
    if(!isNaN(this.busInfo.busId)){
      this.addservice.addBus(this.busInfo).subscribe((data)=>this.message="BUS ADDED");
    }
  }
}