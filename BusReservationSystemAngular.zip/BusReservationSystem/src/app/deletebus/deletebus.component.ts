import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BusInfo, AdminService } from '../service/admin.service';

@Component({
  selector: 'app-deletebus',
  templateUrl: './deletebus.component.html',
  styleUrls: ['./deletebus.component.css']
})
export class DeletebusComponent implements OnInit {

  busInfo: BusInfo = new BusInfo(0,"","",0);
  buses:any
  message: any;

  busid:any;

  constructor(private addService:AdminService,private router:Router) { }

  ngOnInit(): void {
    
  }
  deleteBus(){
    this.addService.deleteBus(this.busid).subscribe((data)=>this.message=data);
  }

}
